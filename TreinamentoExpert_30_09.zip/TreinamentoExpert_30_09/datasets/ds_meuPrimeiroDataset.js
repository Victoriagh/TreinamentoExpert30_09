function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	
	var dataset = DatasetBuilder.newDataset ();
	
	//Cria Colunas
	dataset.addColumn("Sigla");
	dataset.addColumn("Estado");
	dataset.addColumn("Capital");
	dataset.addColumn("Area");
	
	//Cria Registros
	dataset.addRow(new Array("AM","Amazonas","Manaus",157056));
	dataset.addRow(new Array("PA","Para","Belém",157053));
	dataset.addRow(new Array("MT","Mato Grosso","Cuiába",157051));
	dataset.addRow(new Array("TO","Tocantins","Palmas",157051));
	dataset.addRow(new Array("PI","Piauí","Teresina",157050));
	
	return dataset;

}function onMobileSync(user) {

}