function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
var dataset = DatasetBuilder.newDataset ();
	
	//Cria Colunas
	dataset.addColumn("Setor");
	dataset.addColumn("Gestor");
	
	//Cria Registros
	dataset.addRow(new Array("Recursos Humanos","Renato"));
	dataset.addRow(new Array("Tecnologia da Informação","Renata"));
	dataset.addRow(new Array("Comercial","Renato"));
	dataset.addRow(new Array("Financeiro","Renata"));
	dataset.addRow(new Array("Administrativo","Renato"));
	
	return dataset;

}function onMobileSync(user) {

}