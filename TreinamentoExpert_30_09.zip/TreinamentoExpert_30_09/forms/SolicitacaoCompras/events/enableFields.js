function enableFields(form){
	
	//coleta de dados
	var atual = getValue("WKNumState"); //Parametro para integrar como número do processo do form
	var id_form = form.getCardIndex();
		
	//Atividades
	var inicio = "4";
	var analisar_gestor = "22";
	var analisar_financ = "19";
	
	//Arrays
	var habilita = [];
	
	if (atual== inicio || atual== "0"){
		habilita.push("solicitante");
		habilita.push("desc_gestor");
		habilita.push("aprov_gestor");
		habilita.push("desc_financ");
		habilita.push("aprov_financ");
	}
	
	if (atual== analisar_gestor || atual== "0"){
		habilita.push("solicitante");
		habilita.push("desc_financ");
		habilita.push("aprov_financ");
		
	}
	
	
	if (atual== analisar_financ  || atual== "0"){
		habilita.push("solicitante");
		habilita.push("desc_gestor");
		habilita.push("aprov_gestor");
		
		
	}
		
	for (var i=0; i<habilita.length; i++){
		form.setEnabled(habilita[i], false);
	}
	
	
}